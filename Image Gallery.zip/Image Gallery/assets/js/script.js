// var img1 = document.getElementById("img1");
// img1.onclick = function () {
// 	var mainImage = document.getElementById("mainImage");
// 	mainImage.setAttribute('src',this.getAttribute("src", img1));
// }
// var img2 = document.getElementById("img2");
// img2.onclick = function () {
// 	var mainImage = document.getElementById("mainImage");
// 	mainImage.setAttribute('src',this.getAttribute("src", img2));
// }
// var img3 = document.getElementById("img3");
// img3.onclick = function () {
// 	var mainImage = document.getElementById("mainImage");
// 	mainImage.setAttribute('src',this.getAttribute("src", img3));
// }
// var img4 = document.getElementById("img4");
// img4.onclick = function () {
// 	var mainImage = document.getElementById("mainImage");
// 	mainImage.setAttribute('src',this.getAttribute("src", img4));
// }
// var img5 = document.getElementById("img5");
// img5.onclick = function () {
// 	var mainImage = document.getElementById("mainImage");
// 	mainImage.setAttribute('src',this.getAttribute("src", img5));
// }
// var img6 = document.getElementById("img6");
// img6.onclick = function () {
// 	var mainImage = document.getElementById("mainImage");
// 	mainImage.setAttribute('src',this.getAttribute("src", img6));
// }

$(".img").click(function() {
	var img = $(this).attr("src");
	 $("#mainImage").attr("src",img);
});